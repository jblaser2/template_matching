-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 10, 2021 at 09:22 PM
-- Server version: 5.6.51-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tomography`
--

-- --------------------------------------------------------

--
-- Table structure for table `AcquisitionData`
--

CREATE TABLE IF NOT EXISTS `AcquisitionData` (
  `DEF_id` int(11) NOT NULL,
  `DEF_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `acquisitionname` text NOT NULL,
  `TXT_notes` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `DataFile`
--

CREATE TABLE IF NOT EXISTS `DataFile` (
  `DEF_id` int(20) NOT NULL,
  `DEF_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `REF|TiltSeriesData|tiltseries` varchar(24) DEFAULT NULL,
  `TXT_notes` text,
  `filetype` text,
  `auto` int(1) NOT NULL DEFAULT '0',
  `filename` text,
  `grab` tinyint(4) NOT NULL DEFAULT '0',
  `zoom` float NOT NULL DEFAULT '0',
  `xcenter` int(11) NOT NULL DEFAULT '0',
  `ycenter` int(11) NOT NULL DEFAULT '0',
  `zcenter` int(11) NOT NULL DEFAULT '0',
  `xangle` float NOT NULL DEFAULT '0',
  `yangle` float NOT NULL DEFAULT '0',
  `zangle` float NOT NULL DEFAULT '0',
  `REF|ThreeDFile|image` text,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `delete_text` text,
  `delete_time` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `FeatureData`
--

CREATE TABLE IF NOT EXISTS `FeatureData` (
  `DEF_id` int(20) NOT NULL,
  `featurename` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `GroupData`
--

CREATE TABLE IF NOT EXISTS `GroupData` (
  `DEF_id` int(2) NOT NULL,
  `DEF_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` text,
  `description` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ListFeature`
--

CREATE TABLE IF NOT EXISTS `ListFeature` (
  `DEF_id` int(11) NOT NULL,
  `REF|TiltSeriesData|tiltseries` varchar(24) DEFAULT NULL,
  `REF|FeatureData|featurename` text,
  `checked` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `PublicationData`
--

CREATE TABLE IF NOT EXISTS `PublicationData` (
  `DEF_id` int(4) NOT NULL,
  `DEF_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `title` text NOT NULL,
  `authors` text,
  `journal` text,
  `issue` text,
  `pages` text,
  `year` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ScopeData`
--

CREATE TABLE IF NOT EXISTS `ScopeData` (
  `DEF_id` int(11) NOT NULL,
  `DEF_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `scopename` text NOT NULL,
  `TXT_notes` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SpeciesData`
--

CREATE TABLE IF NOT EXISTS `SpeciesData` (
  `DEF_id` int(3) NOT NULL,
  `DEF_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SpeciesName` text NOT NULL,
  `strain` text,
  `tax_id` int(11) DEFAULT '0',
  `TXT_notes` text,
  `count` int(15) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ThreeDFile`
--

CREATE TABLE IF NOT EXISTS `ThreeDFile` (
  `DEF_id` int(20) NOT NULL,
  `DEF_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `REF|TiltSeriesData|tiltseries` varchar(24) DEFAULT NULL,
  `title` text,
  `TXT_notes` text,
  `classify` text,
  `filename` text,
  `pixel_size` double DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `software_process` text,
  `delete_text` text,
  `delete_time` timestamp NULL DEFAULT NULL,
  `tag` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `TiltSeriesData`
--

CREATE TABLE IF NOT EXISTS `TiltSeriesData` (
  `DEF_id` int(20) NOT NULL,
  `DEF_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tiltseriesID` varchar(24) DEFAULT NULL,
  `title` text,
  `TXT_notes` text,
  `time_modified` timestamp NULL DEFAULT NULL,
  `REF|UserData|user` text,
  `tomo_date` date NOT NULL DEFAULT '0000-00-00',
  `keywords` text,
  `roles` text,
  `REF|SpeciesData|specie` text,
  `treatment` text,
  `sample` text,
  `single_dual` int(1) DEFAULT NULL,
  `tilt_min` double DEFAULT NULL,
  `tilt_max` double DEFAULT NULL,
  `tilt_step` text,
  `tilt_constant` int(1) NOT NULL DEFAULT '1',
  `dosage` double DEFAULT NULL,
  `defocus` double DEFAULT NULL,
  `magnification` double DEFAULT NULL,
  `voxel` double DEFAULT '0',
  `scope` text,
  `software_acquisition` text,
  `software_process` text,
  `REF_PublicationData_publication` text,
  `loadmethod` text,
  `loadpath` text,
  `searchtext` text,
  `pubtext` text,
  `raptorcheck` tinyint(4) NOT NULL DEFAULT '0',
  `keyimg` int(1) NOT NULL DEFAULT '0',
  `keymov` int(1) NOT NULL DEFAULT '0',
  `visited` int(11) NOT NULL DEFAULT '0',
  `feature` char(100) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `ispublic` tinyint(4) NOT NULL DEFAULT '0',
  `emdb` varchar(24) DEFAULT NULL,
  `delete_text` text,
  `delete_time` timestamp NULL DEFAULT NULL,
  `pipeline` tinyint(4) NOT NULL DEFAULT '0',
  `proj1` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `UserData`
--

CREATE TABLE IF NOT EXISTS `UserData` (
  `DEF_id` int(3) NOT NULL,
  `DEF_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `username` text,
  `fullname` text,
  `var` text NOT NULL,
  `email` text,
  `count` int(15) NOT NULL DEFAULT '0',
  `REF|GroupData|group` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Workbox`
--

CREATE TABLE IF NOT EXISTS `Workbox` (
  `DEF_id` int(11) NOT NULL,
  `DEF_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `boxname` text,
  `TXT_notes` text,
  `REF|UserData|var` text,
  `time_modified` timestamp NULL DEFAULT NULL,
  `count` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `AcquisitionData`
--
ALTER TABLE `AcquisitionData`
  ADD PRIMARY KEY (`DEF_id`);

--
-- Indexes for table `DataFile`
--
ALTER TABLE `DataFile`
  ADD PRIMARY KEY (`DEF_id`),
  ADD KEY `REF|TiltSeriesData|tiltseries` (`REF|TiltSeriesData|tiltseries`);

--
-- Indexes for table `FeatureData`
--
ALTER TABLE `FeatureData`
  ADD PRIMARY KEY (`DEF_id`);

--
-- Indexes for table `GroupData`
--
ALTER TABLE `GroupData`
  ADD PRIMARY KEY (`DEF_id`);

--
-- Indexes for table `ListFeature`
--
ALTER TABLE `ListFeature`
  ADD PRIMARY KEY (`DEF_id`),
  ADD KEY `REF|TiltSeriesData|tiltseries` (`REF|TiltSeriesData|tiltseries`);

--
-- Indexes for table `PublicationData`
--
ALTER TABLE `PublicationData`
  ADD PRIMARY KEY (`DEF_id`);

--
-- Indexes for table `ScopeData`
--
ALTER TABLE `ScopeData`
  ADD PRIMARY KEY (`DEF_id`);

--
-- Indexes for table `SpeciesData`
--
ALTER TABLE `SpeciesData`
  ADD PRIMARY KEY (`DEF_id`),
  ADD FULLTEXT KEY `SpeciesName` (`SpeciesName`,`strain`);

--
-- Indexes for table `ThreeDFile`
--
ALTER TABLE `ThreeDFile`
  ADD PRIMARY KEY (`DEF_id`);

--
-- Indexes for table `TiltSeriesData`
--
ALTER TABLE `TiltSeriesData`
  ADD PRIMARY KEY (`DEF_id`),
  ADD FULLTEXT KEY `title` (`title`,`TXT_notes`,`tiltseriesID`,`roles`,`treatment`,`sample`,`software_process`,`pubtext`);

--
-- Indexes for table `UserData`
--
ALTER TABLE `UserData`
  ADD PRIMARY KEY (`DEF_id`),
  ADD FULLTEXT KEY `fullname` (`fullname`);

--
-- Indexes for table `Workbox`
--
ALTER TABLE `Workbox`
  ADD PRIMARY KEY (`DEF_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `AcquisitionData`
--
ALTER TABLE `AcquisitionData`
  MODIFY `DEF_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `DataFile`
--
ALTER TABLE `DataFile`
  MODIFY `DEF_id` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `FeatureData`
--
ALTER TABLE `FeatureData`
  MODIFY `DEF_id` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `GroupData`
--
ALTER TABLE `GroupData`
  MODIFY `DEF_id` int(2) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ListFeature`
--
ALTER TABLE `ListFeature`
  MODIFY `DEF_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `PublicationData`
--
ALTER TABLE `PublicationData`
  MODIFY `DEF_id` int(4) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ScopeData`
--
ALTER TABLE `ScopeData`
  MODIFY `DEF_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SpeciesData`
--
ALTER TABLE `SpeciesData`
  MODIFY `DEF_id` int(3) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ThreeDFile`
--
ALTER TABLE `ThreeDFile`
  MODIFY `DEF_id` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `TiltSeriesData`
--
ALTER TABLE `TiltSeriesData`
  MODIFY `DEF_id` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `UserData`
--
ALTER TABLE `UserData`
  MODIFY `DEF_id` int(3) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Workbox`
--
ALTER TABLE `Workbox`
  MODIFY `DEF_id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
